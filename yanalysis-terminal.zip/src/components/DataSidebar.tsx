import React, { useState, useMemo } from "react";
import { Company } from "../data/companies";
import { 
  Activity, 
  TrendingUp, 
  ChevronsLeft, 
  ChevronsRight, 
  Trash2,
  Pin,
  Zap,
  Network,
  Settings
} from "lucide-react";
import { motion } from "motion/react";
import { formatCurrency, cn } from "../lib/utils";
import { TelemetryChart } from "./TelemetryChart";

interface DataSidebarProps {
  selectedStock: Company | null;
  quote: any;
  sentiment: any;
  history: any[];
  financials: any[];
  profile: any;
  isMinimized: boolean;
  onToggleMinimize: () => void;
  pinnedTickers?: string[];
  onTogglePin?: (symbol: string, e: React.MouseEvent) => void;
}

const Sparkline = ({ data }: { data?: any[] }) => {
  const points = useMemo(() => {
    if (!data || data.length === 0) return "";
    
    // Take last 20 historical points if available
    const recentData = data.slice(-20);
    const prices = recentData.map(d => d.close || d.price || 0);
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const range = max - min || 1;

    return recentData.map((d, i) => {
      const x = (i / (recentData.length - 1)) * 100;
      const y = 90 - ((prices[i] - min) / range) * 80; // Scale to 10-90 range
      return `${x},${y}`;
    }).join(' ');
  }, [data]);

  if (!points) return null;

  return (
    <svg className="w-16 h-6 overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
      <polyline
        fill="none"
        stroke="currentColor"
        strokeWidth="6"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
        className="text-emerald-500/60 transition-all duration-1000"
      />
    </svg>
  );
};

export const DataSidebar = React.memo(({
  selectedStock,
  quote,
  sentiment,
  history,
  financials,
  profile,
  isMinimized,
  onToggleMinimize,
  pinnedTickers = [],
  onTogglePin,
}: DataSidebarProps) => {
  const [logs, setLogs] = useState([
    "[ SYSTEM ]: QUANT PORT DISPATCHER RE-ROUTED",
    "[ CACHE ]: HIGH-AVAILABILITY CLOUD RUN TARGET SYNCED",
    "[ RADER ]: SPATIAL TRACKING ENABLED"
  ]);

  React.useEffect(() => {
    if (isMinimized || !selectedStock) return;
    
    const messages = [
      "SIG_SYNC: Receiving telemetry packets...",
      "DATA_NODE: Handshaking with cluster 0xEF...",
      "MKT_VIBE: Calculating volatility coefficients",
      "SENS_RES: Adjusting LOD for deep tracking",
      "KERN_UP: Flushing spatial cache buffers",
      "YIELD_OPT: Optimizing curve projections"
    ];

    const interval = setInterval(() => {
      const msg = messages[Math.floor(Math.random() * messages.length)];
      setLogs(prev => [`[ ${new Date().toLocaleTimeString([], { hour12: false })} ]: ${msg}`, ...prev.slice(0, 8)]);
    }, 4500);

    return () => clearInterval(interval);
  }, [selectedStock, isMinimized]);

  return (
    <aside className={cn(
      "h-full border-r border-zinc-800 flex flex-col bg-black bg-cyber-grid z-25 shrink-0 select-none overflow-hidden relative transition-all duration-150",
      "w-full"
    )}>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-emerald-950/5 pointer-events-none" />
      
      {/* Top Header */}
      <div className="h-10 border-b border-zinc-800 bg-black/90 flex items-center justify-between px-3 shrink-0">
        {!isMinimized && (
          <div className="flex items-center gap-2">
             <div className="relative">
               <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
             </div>
             <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white font-mono">FLOW_TEL_3K</span>
          </div>
        )}
        <div className="flex items-center gap-1.5">
            <button onClick={onToggleMinimize} className="text-zinc-500 hover:text-emerald-500 transition-colors p-1">
              {isMinimized ? <ChevronsRight className="w-4 h-4" /> : <ChevronsLeft className="w-4 h-4" />}
            </button>
        </div>
      </div>

      {!isMinimized && (
        <div className="flex-1 flex flex-col overflow-y-auto custom-scrollbar">
          {/* Target Title & Spot price */}
          {selectedStock ? (
            <>
              <div className="p-3 border-b border-zinc-900 bg-black shrink-0 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-8 h-8 bg-emerald-500/5 rotate-45 translate-x-4 -translate-y-4 border border-emerald-500/20" />
                
                <div className="relative z-10">
                  <div className="flex items-end justify-between gap-1 mb-1">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[8px] text-zinc-650 font-mono font-bold uppercase tracking-[0.2em] block">PANEL H: TARGET INDEX</span>
                        {onTogglePin && (
                          <button
                            onClick={(e) => onTogglePin(selectedStock.symbol, e)}
                            className={cn(
                              "flex items-center gap-1 px-1.5 py-0.5 rounded transition-all border",
                              pinnedTickers.includes(selectedStock.symbol)
                                ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-400 font-extrabold hover:bg-emerald-500/30"
                                : "bg-black border-zinc-800 text-zinc-500 hover:border-zinc-700 hover:text-zinc-300"
                            )}
                            title={pinnedTickers.includes(selectedStock.symbol) ? "Unpin from monitor list" : "Pin to monitor list"}
                          >
                            <Pin className={cn("w-2.5 h-2.5", pinnedTickers.includes(selectedStock.symbol) ? "fill-emerald-400 text-emerald-400" : "text-zinc-500")} />
                            <span className="text-[7.5px] font-mono leading-none tracking-widest uppercase">
                              {pinnedTickers.includes(selectedStock.symbol) ? "PINNED" : "PIN"}
                            </span>
                          </button>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <h2 className="font-sans text-xl text-white font-black tracking-tighter leading-none">{selectedStock.symbol}</h2>
                        <span className="text-[8.5px] text-zinc-500 font-mono font-bold">// {selectedStock.name}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 font-mono text-[7px] mt-2">
                    <span className="text-zinc-500 uppercase px-1 border border-zinc-900 bg-black">{profile?.exchangeShortName || "EXCH"}</span>
                    <span className="text-zinc-700 opacity-30">•</span>
                    <div className="flex items-center gap-2 tabular-nums">
                      <span className="text-white text-lg font-bold">${quote?.price?.toFixed(2) || "N/A"}</span>
                      {quote && typeof quote.changesPercentage === 'number' && (
                        <span className={cn("text-xs font-bold", quote.changesPercentage >= 0 ? "text-emerald-400" : "text-red-400")}>
                          {quote.changesPercentage > 0 ? "+" : ""}{quote.changesPercentage.toFixed(2)}%
                        </span>
                      )}
                    </div>
                    <div className="ml-auto flex items-center gap-1 text-zinc-600">
                      <div className="w-1 h-1 bg-zinc-800 rounded-full" />
                      <span>LIVE</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Price Performance Chart */}
              <div className="p-3 border-b border-zinc-900 bg-black/10">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[8.5px] font-mono text-zinc-500 uppercase tracking-widest flex items-center gap-1.5 font-bold">
                    <TrendingUp className="w-2.5 h-2.5" /> PANEL I: TELEMETRY TREND CHART
                  </span>
                  <span className="text-[8.5px] font-mono text-zinc-600">30D TREND</span>
                </div>
                <div className="h-[145px] w-full">
                  <TelemetryChart data={history} aiForecast={sentiment?.forecast} ticker={selectedStock.symbol} />
                </div>
              </div>

              {/* Technical Indicator Gauges */}
              <div className="p-2.5 border-b border-zinc-900 bg-black/40">
                <div className="text-[7.5px] text-zinc-500 font-mono font-bold uppercase tracking-widest mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <div className="w-1 h-1 bg-blue-500 rounded-full animate-ping absolute inset-0" />
                      <div className="w-1 h-1 bg-blue-500 rounded-full relative z-10" />
                    </div>
                    <span>PANEL J: TECHNICAL OSCILLATORS</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[6px] text-zinc-600 font-mono">ID: {selectedStock.symbol}_TECH_PULSE</span>
                    <Settings className="w-2 h-2 text-zinc-700" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { 
                      label: "RSI (14)", 
                      val: sentiment?.rsi?.toFixed(2) || ((selectedStock.symbol.charCodeAt(0) % 40) + 42).toFixed(2), 
                      color: "#7e72a2", // RSI Purple
                      type: 'area',
                      signal: (sentiment?.rsi || (selectedStock.symbol.charCodeAt(0) % 40) + 42) > 70 ? "Overbought" : (sentiment?.rsi || (selectedStock.symbol.charCodeAt(0) % 40) + 42) < 30 ? "Oversold" : "Neutral"
                    },
                    { 
                      label: "MACD Hist", 
                      val: (selectedStock.symbol.charCodeAt(0) % 2 ? "+" : "-") + (0.15 + (selectedStock.symbol.charCodeAt(1) % 10) / 20).toFixed(2), 
                      color: "#22ab94", // TradingView Green
                      type: 'histogram',
                      signal: "Bullish"
                    },
                    { 
                      label: "Vol. Osc", 
                      val: quote?.volume ? "1.2x" : "0.8x", 
                      color: "#2962ff", // TradingView Blue
                      type: 'bars',
                      signal: "Normal"
                    },
                    { 
                      label: "ADX (14)", 
                      val: ((selectedStock.symbol.charCodeAt(0) % 30) + 15).toFixed(1), 
                      color: "#f23645", // TradingView Red
                      type: 'line',
                      signal: "Strong"
                    },
                    { 
                      label: "Stoch %K", 
                      val: ((selectedStock.symbol.charCodeAt(2) || 72) % 60 + 20).toFixed(1), 
                      color: "#ff9800", // Orange
                      type: 'stoch',
                      signal: "Momentum"
                    },
                    { 
                      label: "ATR (14)", 
                      val: sentiment?.atr?.toFixed(3) || (selectedStock.symbol.charCodeAt(1) % 5 + 1.25).toFixed(3), 
                      color: "#b2b5be", // Gray
                      type: 'line',
                      signal: "Volatile"
                    }
                  ].map((sig) => {
                    // Generate deterministic sparkline data
                    const points = 20;
                    const pathData = Array.from({ length: points }).map((_, i) => {
                      const seed = selectedStock.symbol.charCodeAt(0) + sig.label.length;
                      const noise = Math.sin(i * 0.8 + seed) * 10 + Math.cos(i * 0.4 + seed) * 5;
                      const val = 50 + noise;
                      return { x: (i / (points - 1)) * 100, y: Math.max(10, Math.min(90, val)) };
                    });

                    return (
                      <div key={sig.label} className="p-2 border border-zinc-900 bg-black rounded-sm group hover:border-[#2962ff]/50 transition-all cursor-crosshair">
                        <div className="flex justify-between items-start mb-1 text-zinc-400">
                          <div className="text-[6.5px] font-bold tracking-tight">{sig.label}</div>
                          <div className="text-[8px] font-mono font-black tabular-nums">{sig.val}</div>
                        </div>
                        
                        <div className="h-8 w-full relative mb-1.5 bg-black/20 rounded-xs overflow-hidden">
                          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                            {/* TradingView-style grid line at 50% */}
                            <line x1="0" y1="50" x2="100" y2="50" stroke="rgba(255,255,255,0.05)" strokeWidth="0.5" strokeDasharray="2,2" />
                            
                            {sig.type === 'area' && (
                              <>
                                {/* RSI Shaded Zone */}
                                <rect x="0" y="30" width="100" height="40" fill="#7e72a2" fillOpacity="0.05" />
                                <path 
                                  d={`M ${pathData[0].x} ${pathData[0].y} ${pathData.map(p => `L ${p.x} ${p.y}`).join(' ')}`}
                                  fill="none"
                                  stroke={sig.color}
                                  strokeWidth="1.5"
                                  className="drop-shadow-[0_0_2px_rgba(126,114,162,0.5)]"
                                />
                              </>
                            )}
                            
                            {sig.type === 'histogram' && (
                              pathData.map((p, i) => (
                                <rect 
                                  key={i}
                                  x={p.x - 1} 
                                  y={p.y > 50 ? 50 : p.y} 
                                  width="2" 
                                  height={Math.abs(50 - p.y)} 
                                  fill={p.y < 50 ? "#22ab94" : "#f23645"} 
                                  fillOpacity="0.7"
                                />
                              ))
                            )}
                            
                            {sig.type === 'bars' && (
                              pathData.map((p, i) => (
                                <rect 
                                  key={i}
                                  x={p.x - 1} 
                                  y={p.y} 
                                  width="1.5" 
                                  height={100 - p.y} 
                                  fill="#2962ff" 
                                  fillOpacity={i === points - 1 ? "1" : "0.4"}
                                />
                              ))
                            )}
                            
                            {(sig.type === 'line' || sig.type === 'stoch') && (
                              <path 
                                d={`M ${pathData[0].x} ${pathData[0].y} ${pathData.map(p => `L ${p.x} ${p.y}`).join(' ')}`}
                                fill="none"
                                stroke={sig.color}
                                strokeWidth="1.2"
                              />
                            )}
                          </svg>
                        </div>

                        <div className="flex justify-between items-center text-[5.5px] font-mono leading-none">
                          <span className={cn(
                            "px-1 py-0.5 rounded-[2px]",
                            ["Overbought", "Bullish", "Strong", "Trending", "Momentum"].includes(sig.signal) ? "bg-emerald-500/10 text-emerald-500" :
                            ["Oversold", "Volatile"].includes(sig.signal) ? "bg-rose-500/10 text-rose-500" :
                            "bg-zinc-800 text-zinc-500"
                          )}>
                            {sig.signal}
                          </span>
                          <span className="text-zinc-600">CONF: 0.89</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Valuation & Core Metrics Grid */}
              <div className="grid grid-cols-2 gap-px border border-emerald-950/40 bg-emerald-950/10 p-1.5 flex-none min-h-[100px]">
                {[
                  { label: 'MKT CAP', value: profile?.mktCap ? formatCurrency(profile.mktCap) : "PENDING" },
                  { label: 'P/E RATIO', value: profile?.peRatio?.toFixed(2) || "PENDING" },
                  { label: 'DIV YIELD', value: profile?.divYield ? `${(profile.divYield * 100).toFixed(2)}%` : "N/A" },
                  { label: 'BETA', value: profile?.beta?.toFixed(2) || "PENDING" },
                  { label: 'REVENUE', value: financials?.[0]?.revenue ? formatCurrency(financials[0].revenue) : "PENDING" },
                  { label: 'NET INCOME', value: financials?.[0]?.netIncome ? formatCurrency(financials[0].netIncome) : "PENDING" },
                  { label: 'DEBT/EQUITY', value: profile?.debtToEquity?.toFixed(2) || "PENDING" },
                  { label: 'VOLUME', value: quote?.volume ? formatCurrency(quote.volume) : "PENDING" },
                ].map((metric) => (
                  <div key={metric.label} className="bg-black/90 px-2 py-1 flex justify-between items-center border border-zinc-900/60 rounded-xs hover:border-emerald-500/20 transition-colors">
                    <span className="text-[8px] font-mono text-zinc-605 uppercase">{metric.label}</span>
                    <span className="text-[8.5px] font-mono text-emerald-500 font-black">{metric.value}</span>
                  </div>
                ))}
              </div>

              {/* 6Q Net Income P&L Trend sparkline */}
              <div className="px-3 py-1.5 font-sans text-[10px] border-b border-zinc-900 bg-black/20 flex items-center justify-between">
                <span className="text-[7.5px] text-zinc-600 uppercase font-bold tracking-widest block">P&L Hist Trend (6-Quarter)</span>
                {financials && financials.length > 0 ? (
                  <div className="w-16 h-4 opacity-70">
                    <Sparkline data={financials.map(f => ({ close: f.netIncome }))} />
                  </div>
                ) : (
                  <div className="text-[8px] font-mono text-zinc-800">[ UNAVAILABLE ]</div>
                )}
              </div>

              {/* Micro terminal logs for visual flare */}
              <div className="h-24 bg-black border-t border-zinc-900 flex flex-col shrink-0">
                <div className="px-3 py-1 bg-black/80 border-b border-zinc-900 flex items-center justify-between">
                  <span className="text-[7px] text-zinc-600 font-mono">PANEL K: D_LOGISTIC_TEL_STREAM</span>
                  <div className="w-1.5 h-1.5 bg-emerald-500/80 rounded-full" />
                </div>
                <div className="flex-1 overflow-y-auto p-2 font-mono text-[8px] text-emerald-500/70 scrollbar-none select-text">
                  {logs.map((log, i) => (
                    <div key={i} className="mb-0.5 leading-tight hover:text-emerald-400 transition-colors">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-4 text-center">
              <Activity className="w-8 h-8 text-zinc-800 mb-3" />
              <h3 className="font-mono text-zinc-500 uppercase tracking-[0.3em] font-black text-[9px]">TARGET REQUIRED</h3>
              <p className="text-[7.5px] font-mono text-zinc-650 mt-2 uppercase tracking-wider">Select an asset marker to load pricing signals.</p>
            </div>
          )}
        </div>
      )}
    </aside>
  );
});
